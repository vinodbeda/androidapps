package com.example.bmiapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends Activity {
	EditText hgt_ft,hgt_in,wgt;
	Button CalculateBMI;
	ImageView arrow;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		hgt_ft=(EditText)findViewById(R.id.editText1);
		hgt_in=(EditText)findViewById(R.id.editText2);
		wgt=(EditText)findViewById(R.id.editText3);
		CalculateBMI=(Button)findViewById(R.id.button1);
		arrow=(ImageView)findViewById(R.id.imageView1);
	}

	public void Calc(View v)
	{
		
		double hgt=(Double.parseDouble( hgt_ft.getText().toString())*12) 
				+Double.parseDouble( hgt_in.getText().toString());
		double weight= Double.parseDouble(wgt.getText().toString())*2.204;
		
		double BMI= (weight*703)/(hgt*hgt);
		int angle= (int) (BMI*3.6);
		
		RotateAnimation rotateNeddle;
		
		rotateNeddle = new RotateAnimation(0, angle,
				RotateAnimation.RELATIVE_TO_SELF, 0.9f,
				RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		 
		rotateNeddle.setDuration(10000);
		rotateNeddle.setFillAfter(true);
		arrow.startAnimation(rotateNeddle);
		
	}

}
