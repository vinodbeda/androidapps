/** Automatically generated file. DO NOT MODIFY */
package com.example.quizdb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}