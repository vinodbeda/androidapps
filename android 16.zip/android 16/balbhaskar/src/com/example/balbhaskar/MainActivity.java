package com.example.balbhaskar;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {
	DrawingView dr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dr=(DrawingView)findViewById(R.id.drawingView1);
    }
    public void clearFunction(View a)
    {
    	drView.clear();
    	
    }
   
    public void incSize(View a)
    {
    	drawingView.STROKE_WIDTH+=5;
    	
    }
    public void changeCoLor(View a)
    {
    	drawingView.clr=Color.RED;
    	
    }
   
   
}
