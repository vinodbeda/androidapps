/** Automatically generated file. DO NOT MODIFY */
package com.splash21st;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}