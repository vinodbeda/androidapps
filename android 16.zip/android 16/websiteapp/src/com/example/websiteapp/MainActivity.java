package com.example.websiteapp;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class MainActivity extends Activity {
	WebView myBrowser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myBrowser=(WebView)findViewById(R.id.webView1);
    }
        	
        	public boolean shouldOverrideUrLoading(WebView view, String url){
        		view.loadUrl(url);
        		return true;
        	}
        	 public void OpenSite(View a)
        	 {
        		 Button btn=(Button)a;
        		 if(btn.getId()==R.id.button1)
        		 myBrowser.loadUrl("http://www.myntra.com");
        		 else
        			 myBrowser.loadUrl("http://www.jabong.com");
        	 }
        	
        	
       
    

   
}
