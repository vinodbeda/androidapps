package com.example.animation;

import java.util.Random;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.RotateAnimation;
import android.widget.Button;

public class MainActivity extends Activity {
Button Arrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Arrow = (Button)findViewById(R.id.button1);
       Arrow.setOnClickListener(new OnClickListener(){
    	   
    	   @Override
    	   public void onClick(View a)
    	   {
    		   RotateAnimation rotateNeedle;
    		   int angle=new Random().nextInt(361)+3600;
    		   rotateNeedle=new RotateAnimation(0,angle,
    				   RotateAnimation.RELATIVE_TO_SELF,0.5f,
    				   RotateAnimation.RELATIVE_TO_SELF,0.5f);
    		   rotateNeedle.setDuration(1000);
    		   rotateNeedle.setFillAfter(true);
    		   Arrow.startAnimation(rotateNeedle);
    		   
    		   
    		   
    	   }
       });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
}
