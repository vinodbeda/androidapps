package com.example.v10xwebsolutions;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class MainActivity extends Activity {
	WebView myBrowser;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		myBrowser=(WebView)findViewById(R.id.webView1);
		myBrowser.setWebViewClient(new WebViewClient()
		{
			public boolean shouldOverrideUrlLoading
			(WebView view,String url)
			{
				view.loadUrl(url);
				return true;
			}
			
			
		}
				
				);
	}

	 public void OpenSite(View a)
	 {
		 Button btn=(Button)a;
		 if(btn.getId()==R.id.button1)
		 myBrowser.loadUrl("http://www.10xweb.wordpress.com");
		 else
			 myBrowser.loadUrl("http://www.flipkart.com");
	 }

}
