/** Automatically generated file. DO NOT MODIFY */
package com.example.v10xwebsolutions;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}