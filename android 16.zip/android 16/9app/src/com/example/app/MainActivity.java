package com.example.app;
import java.io.File;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class FirstActivity extends Activity {

	TextView txtText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_first);
		txtText = (TextView) findViewById(R.id.editText1);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.first, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
		switch (item.getItemId()) {
		case R.id.sharingText:
			if (!txtText.getText().toString().isEmpty()) {

				shareIntent.setType("text/plain");
				shareIntent.putExtra(android.content.Intent.EXTRA_TEXT, txtText
						.getText().toString());
				startActivity(Intent.createChooser(shareIntent,
						"Share Text Via"));
			} else {
				Toast.makeText(getApplicationContext(),
						"Empty field, can't share ", Toast.LENGTH_LONG).show();
			}
			break;

		case R.id.sharingImage:
		//	Intent shareIntent = new Intent(Intent.ACTION_SEND);
			shareIntent.setType("image/*");
			//File file=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/Pictures/s.png");
			Uri file2=Uri.parse("android.resource://"+getPackageName()+"/drawable/ic_launcher.png");
			shareIntent.putExtra("android.intent.extra.STREAM", file2);
			/*
			 * if (Build.VERSION.SDK_INT < 11)
			 * shareIntent.setPackage("com.android.bluetooth"); else shareIntent
			 * .setComponent(new ComponentName( "com.android.bluetooth",
			 * "com.android.bluetooth.opp.BluetoothOppLauncherActivity"));
			 */
			startActivity(Intent.createChooser(shareIntent, "Share Image Via"));
			break;
		}
		return super.onOptionsItemSelected(item);
	}

}
