package com.example.dancingquizapp;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	Button fiftyFifty,doubleDip,skip,Op1,Op2,Op3,Op4;
	TextView QuestionTxt,ScoreTxt;
	private ArrayList<Lucky> array;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		fiftyFifty=(Button)findViewById(R.id.button5);
		doubleDip=(Button)findViewById(R.id.button6);
		skip=(Button)findViewById(R.id.button7);
		Op1=(Button)findViewById(R.id.button1);
		Op2=(Button)findViewById(R.id.button2);
		Op3=(Button)findViewById(R.id.button3);
		Op4=(Button)findViewById(R.id.button4);
		QuestionTxt=(TextView)findViewById(R.id.textView1);
		ScoreTxt=(TextView)findViewById(R.id.textView2);
		
DBAdapter dbObject=DBAdapter.getDBAdapter(getApplicationContext());
        
        if(!dbObject.checkDatabase())
        {
        	dbObject.createDatabase(getApplicationContext());
        }
        dbObject.openDatabase();
        array=dbObject.getData();
        QuestionTxt.setText(array.get(0).getQuestion());
        Op1.setText(array.get(0).getOption1());
        Op2.setText(array.get(0).getOption2());
        Op3.setText(array.get(0).getOption3());
        Op4.setText(array.get(0).getOption4());
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
