package com.example.tabriya;

import java.io.InputStream;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity
{
	DrawingView drngV;
	Bitmap btm;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		drngV=(DrawingView)findViewById(R.id.drawingView1);
	}
	public void clearcnvs(View a)
	{
		drngV.clear();
	}
	public void chngclr(View a)
	{
		Button btn=(Button)a;
		if(btn.getId()==R.id.button1)
			DrawingView.clr=Color.RED;
		else if(btn.getId()==R.id.Button01)
			DrawingView.clr=Color.BLUE;
		else if(btn.getId()==R.id.Button02)
			DrawingView.clr=Color.CYAN;
		else if(btn.getId()==R.id.Button03)
			DrawingView.clr=Color.YELLOW;
		else if(btn.getId()==R.id.Button04)
			DrawingView.clr=Color.GREEN;
		else if(btn.getId()==R.id.Button05)
			DrawingView.clr=Color.MAGENTA;
	}
	public void erase(View a)
	{
		DrawingView.clr=Color.WHITE;
	}
	public void sizechng(View a)
	{
		Button btn=(Button)a;
		if(btn.getId()==R.id.button2)
			DrawingView.STROKE_WIDTH+=2;
		else if(btn.getId()==R.id.Button06)
			DrawingView.STROKE_WIDTH-=2;
	}
	public void camera(View a)
	{
		switch(a.getId())
		{
		case R.id.button6:
			Intent camon=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(camon, 2);
			break;
			
		case R.id.button5:
			Intent galon=new Intent(Intent.ACTION_PICK);
			galon.setType("image/*");
			startActivityForResult(galon, 4);
		}
	}
	
	protected void onActivityResult(int rqstCode, int rsltCode, Intent bag)
	{
		super.onActivityResult(rqstCode, rsltCode, bag);
		Drawable dd;
		if(rsltCode== RESULT_OK)
		{
			try
			{
				if(rqstCode==2)
				{
					btm=(Bitmap)bag.getExtras().get("data");
					dd=new BitmapDrawable(getResources(),btm);
					drngV.setBackgroundDrawable(dd);
				}
				else if(rqstCode==4)
				{
					Uri drngVadd=bag.getData();
					InputStream mydrngV=getContentResolver().openInputStream(drngVadd);
					btm=BitmapFactory.decodeStream(mydrngV);
					dd=new BitmapDrawable(getResources(),btm);
					drngV.setBackgroundDrawable(dd);
				}
			}
			catch(Exception e)
			{
				
			}
		}
	}
	public void shareApp(View s)
	{
		
	}
}