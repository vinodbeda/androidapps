/** Automatically generated file. DO NOT MODIFY */
package com.example.tabriya;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}